TF3 原創卡 MDPro4 自訂卡測試包（原型）

包含：
- 風箏機器人（カイトロイド）自訂卡 ID 99000001
- 火山之壁（ヴォルカニック・ウォール）自訂卡 ID 99000002
- custom.cdb、Lua 腳本、測試卡圖、測試牌組

重要限制：
1. 卡圖目前是自製佔位圖，不是 TF3 原始卡圖。
2. 卡片 ID 使用 99000001/99000002，避免與正式卡號衝突；若本機已有相同 ID，請勿直接安裝。
3. Lua 腳本是原型，未在使用者的 MDPro4 實機環境執行。尤其傷害步驟時點、墓地除外效果與本回合禁止攻擊的處理，可能需要依 MDPro4 內附的 ocgcore/API 調整。
4. 先備份 D:\Games\MDPro4，再透過 SETTINGS → EXPANSIONS → Download Custom Card Pack 安裝 .ypk，或依你的版本自訂卡說明安裝。不要覆蓋原本 cards.cdb。
5. .ypk 是 ZIP 容器，包含 custom.cdb、pics/、script/、pack/、test-strings.conf。

原始效果參考：
- Kiteroid (Tag Force 3): https://ftp.yugipedia.com/wiki/Kiteroid_%28Tag_Force_3%29
- Volcanic Wall (Tag Force 3): https://ftp.yugipedia.com/wiki/Volcanic_Wall_%28Tag_Force_3%29

本包目的：先驗證 MDPro4 能否載入自訂資料、顯示卡圖與讀取腳本；並非已保證效果完全還原的正式成品。
