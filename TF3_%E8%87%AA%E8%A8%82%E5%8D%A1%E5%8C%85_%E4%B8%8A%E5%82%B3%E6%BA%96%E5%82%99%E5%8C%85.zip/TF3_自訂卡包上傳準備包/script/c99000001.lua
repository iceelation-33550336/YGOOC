-- TF3 prototype: Kiteroid (custom card)
-- Effect implementation based on the TF3 text; test on the target MDPro4 build.
local s,id=GetID()
function s.initial_effect(c)
  -- Hand effect: negate battle damage from a direct attack
  local e1=Effect.CreateEffect(c)
  e1:SetDescription(aux.Stringid(id,0))
  e1:SetCategory(CATEGORY_DAMAGE)
  e1:SetType(EFFECT_TYPE_QUICK_O)
  e1:SetCode(EVENT_PRE_DAMAGE_CALCULATE)
  e1:SetRange(LOCATION_HAND)
  e1:SetCondition(s.handcon)
  e1:SetCost(s.handcost)
  e1:SetOperation(s.handop)
  c:RegisterEffect(e1)
  -- GY effect: banish this card to prevent direct-attack battle damage once
  local e2=Effect.CreateEffect(c)
  e2:SetDescription(aux.Stringid(id,1))
  e2:SetType(EFFECT_TYPE_QUICK_O)
  e2:SetCode(EVENT_PRE_DAMAGE_CALCULATE)
  e2:SetRange(LOCATION_GRAVE)
  e2:SetCondition(s.gycon)
  e2:SetCost(s.gycost)
  e2:SetOperation(s.gyop)
  c:RegisterEffect(e2)
end
function s.directattack()
  local a=Duel.GetAttacker()
  return a and a:IsDirectAttack()
end
function s.handcon(e,tp,eg,ep,ev,re,r,rp)
  return Duel.GetTurnPlayer()~=tp and s.directattack()
end
function s.handcost(e,tp,eg,ep,ev,re,r,rp,chk)
  if chk==0 then return e:GetHandler():IsDiscardable() end
  Duel.SendtoGrave(e:GetHandler(),REASON_COST+REASON_DISCARD)
end
function s.handop(e,tp,eg,ep,ev,re,r,rp)
  if s.directattack() then Duel.ChangeBattleDamage(1-tp,0) end
end
function s.gycon(e,tp,eg,ep,ev,re,r,rp)
  return Duel.GetTurnPlayer()~=tp and s.directattack() and not e:GetHandler():IsStatus(STATUS_BATTLE_DESTROYED)
end
function s.gycost(e,tp,eg,ep,ev,re,r,rp,chk)
  if chk==0 then return e:GetHandler():IsAbleToRemoveAsCost() end
  Duel.Remove(e:GetHandler(),POS_FACEUP,REASON_COST)
end
function s.gyop(e,tp,eg,ep,ev,re,r,rp)
  if s.directattack() then Duel.ChangeBattleDamage(1-tp,0) end
end
