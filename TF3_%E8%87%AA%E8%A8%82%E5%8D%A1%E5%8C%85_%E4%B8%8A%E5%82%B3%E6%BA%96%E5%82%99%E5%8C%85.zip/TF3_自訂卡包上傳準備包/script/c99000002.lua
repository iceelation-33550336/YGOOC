-- TF3 prototype: Volcanic Wall (custom card)
-- Continuous Spell: mill 3, inflict 500 per Pyro sent; your monsters cannot attack this turn.
local s,id=GetID()
function s.initial_effect(c)
  local e1=Effect.CreateEffect(c)
  e1:SetDescription(aux.Stringid(id,0))
  e1:SetType(EFFECT_TYPE_IGNITION)
  e1:SetRange(LOCATION_SZONE)
  e1:SetCountLimit(1,id)
  e1:SetOperation(s.operation)
  c:RegisterEffect(e1)
end
function s.operation(e,tp,eg,ep,ev,re,r,rp)
  if not Duel.IsPlayerCanDiscardDeck(tp,3) then return end
  local g=Duel.GetDecktopGroup(tp,3)
  if #g==0 then return end
  local sent=Duel.SendtoGrave(g,REASON_EFFECT)
  local pyro=0
  local mg=g:Filter(Card.IsLocation,nil,LOCATION_GRAVE)
  for tc in aux.Next(mg) do
    if tc:IsRace(RACE_PYRO) then pyro=pyro+1 end
  end
  if pyro>0 then Duel.Damage(1-tp,pyro*500,REASON_EFFECT) end
  local e1=Effect.CreateEffect(e:GetHandler())
  e1:SetType(EFFECT_TYPE_FIELD)
  e1:SetCode(EFFECT_CANNOT_ATTACK_ANNOUNCE)
  e1:SetTargetRange(LOCATION_MZONE,0)
  e1:SetReset(RESET_PHASE+PHASE_END)
  Duel.RegisterEffect(e1,tp)
end
